score = 128
assert score <= 100, "점수는 100 이하여야 합니다"
print(score)