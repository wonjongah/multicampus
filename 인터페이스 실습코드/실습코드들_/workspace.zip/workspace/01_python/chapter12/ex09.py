import sys


print(sys.argv)

# [파일경로, 인자1, 인자2,...]
# terminal에 python ex09.py a b 10 110
# edit cofi~~~에 들어가서 parameter에 들어가서 변경하면 굳이 파이썬 어쩌구저쩌구 안 써도 된다
# 파라미터에 공백 있는 문자열 넣고 싶을 때는 따옴표로 묶어준다