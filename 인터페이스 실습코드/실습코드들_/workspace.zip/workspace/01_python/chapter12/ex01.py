import math
from math import sqrt
import math as m
from math import sqrt as sq

print(math.sqrt(2))
print(sqrt(2))
print(m.sqrt(2))
print(sq(2))