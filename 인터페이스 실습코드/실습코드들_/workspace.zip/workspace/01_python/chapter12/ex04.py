import time

print("안녕하세요")
time.sleep(1)
print("밤에 성시경이 두 명 있으면 무엇일까요?")
time.sleep(5)
print("야간투시경")

# 500ms 동안 중지시키고 싶다  --> 0.5
# 1s = 1000ms