import calendar as cal

print(cal.calendar(2020))
print(cal.month(2020,8))