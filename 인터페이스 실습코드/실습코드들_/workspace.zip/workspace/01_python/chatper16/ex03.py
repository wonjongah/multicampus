import math
help(math.hypot)