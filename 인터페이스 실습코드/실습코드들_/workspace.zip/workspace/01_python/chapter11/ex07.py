def main():

    lst = []


main()