def add(a, b):
    print(a + b)


plus = add
plus(1, 2)