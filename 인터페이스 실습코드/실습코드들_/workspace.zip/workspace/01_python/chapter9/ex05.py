def main():
    lol = [
        [1,2,3],
        [4,5],
        [6,7,8,9]
        ]
    print(lol[0])
    print(lol[2][1])

    for sub in lol:
        for item in sub:
            print(item, end='')
        print()
def sample(*args=):
    #args == tuple(...);
    #return

a = {"s":2}
a = dict(((1,2),(3,4)))
# {1:2, 3:4)

from collections import defaultdict

S =defaultdict(2)

S["asd"] ="";
(S["asd"])

if __name__ == '__main__':
    sample() = tuple()



main()