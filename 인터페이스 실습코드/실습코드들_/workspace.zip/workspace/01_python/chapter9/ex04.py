def main():

    list1 = list(range(1,6))
    list2 = [10,11]
    listadd = list1 + list2
    print(listadd)
    listmulti = list2 * 3
    print(listmulti)


main()