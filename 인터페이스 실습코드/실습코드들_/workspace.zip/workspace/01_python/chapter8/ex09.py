trabler ="""
강나루 건너서
밀밭 길을

구름에 달 가듯이
가는 나그네
"""


poet = trabler.splitlines()
for line in poet:
    print(line)
print(len(poet))

s = "._."
print(s.join("대한민국"))
print("._.".join("대한민국"))
