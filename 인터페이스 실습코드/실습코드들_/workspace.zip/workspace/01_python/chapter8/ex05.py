def main():
    s = "python programming"
    print(len(s))
    print(s.find('k'))
    print(s.rfind('o'))
    print(s.index('r'))
    print(s.count('n'))


main()

