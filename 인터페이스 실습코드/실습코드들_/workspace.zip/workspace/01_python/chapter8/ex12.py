def main():
    f = 123.1234567
    print("%10f" % f)
    print("%10.8f" % f)
    print("%10.5f" % f)
    print("%10.2f" % f)
    print("%.2f" % 123.126)


main()