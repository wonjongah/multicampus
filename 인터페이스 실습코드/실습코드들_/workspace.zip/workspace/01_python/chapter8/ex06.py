def main():
    s = "hello"
    print(s[2])
    s[2] = "L"    # 문자열은 불변객체, 에러


main()