age = int(input("나이를 입력하세요: "))
if age < 19:
    print("애들은 가라")
    print("하하")
