age = int(input("나이를 입력하세요 : "))
if age < 19:
    print("애들은 가라")
    print("공부 열심히 하세요")
else:
    print("들어오세요")
    print("즐거운 시간 되세요")