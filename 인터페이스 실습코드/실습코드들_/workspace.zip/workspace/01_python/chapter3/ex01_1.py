print(26)
print(hex(26)) # hex는 16진수
print(oct(26)) # oct는 8진수
print(bin(26)) # bin은 2진수
