age = int(input("나이를 입력하세요"))
if age < 19:
    print("애들은 가라")
elif age < 25:
    print("대학생")
else:
    print("들어오세요")