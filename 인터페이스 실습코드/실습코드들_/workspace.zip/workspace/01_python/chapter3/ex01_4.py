s = """한 줄의
후후"""
print(s)

linecontinue = "강나루 \
랄랄랄\
하하하하"
print(linecontinue)

s = "korea" "japan" "2002"
print(s)

s = ("korea"
     "japan"
     "2002")
print(s)