a = 5
b = a ==5
print(type(b))
print(b)

if a == 5:
    print('a는 5입니다')

    a = None
    print(a)
