member = ['손오공', '저팔계', '사오정', '삼장법사', 23]
print(type(member))
print(member)

member = ('손오공', '저팔계','사오정', '삼장법사')
print(type(member))
print(member)