a = "I Say \"Hello\" to you"
print(a)
a = 'I Say \'Hello\' to you'
print(a)

a = 'first\nsecond'
print(a)

a = 'first\tsecond'
print(a)

a = 'first\rsecond'
print(a)