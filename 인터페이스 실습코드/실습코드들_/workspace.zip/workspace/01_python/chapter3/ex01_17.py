print(5/2)
print(5//2)

print(7%2)
print(8%3)
print(9%3)

print("홀짝 뭘까")
a = int(input("정수를 입력하세요"))
if a % 2 == 0:
    print("짝수")
else:
    print("홀수")