country = "Korea"

if country == "Korea":
    print("한국입니다")
if country != "Korea":
    print("한국이 아닙니다")

if "korea" > "japan":
    print("한국이 더 크다")
if "korea" < "japan":
    print("일본이 더 크다")

if "Korea" > "korea":
    print("Korea가 더 큽니다")
if "Korea" < "korea":
    print("korea가 더 큽니다")

print(ord("K"))
print(ord("k"))