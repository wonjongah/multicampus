x = 10
y = 20

# x와 y의 값을 교환하세요

temp = y
y = x
x = temp

print("x: ", x)
print("y: ", y)
