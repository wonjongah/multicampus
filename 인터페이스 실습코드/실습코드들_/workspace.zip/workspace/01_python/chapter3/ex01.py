a = 1234
print(a)
print(a**100)

# 거듭제곱