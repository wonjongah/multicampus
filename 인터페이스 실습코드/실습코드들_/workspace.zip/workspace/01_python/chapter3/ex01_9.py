a = 3
if a == 3:
    print('3이다')

if a > 5:
    print('5보다 크다')

if a< 5:
    print('5보다 작다')
