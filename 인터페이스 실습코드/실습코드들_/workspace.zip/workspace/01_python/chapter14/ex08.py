def main():
    f = open("live.txt", "at")
    f.write("\n\n푸쉬킨 형님의 말씀")
    f.close()


main()