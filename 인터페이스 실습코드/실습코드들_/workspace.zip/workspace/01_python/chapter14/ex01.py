
f = open("live.txt", "wt", encoding="utf8")
f.write("""삶이 그대를 속일지라도
슬퍼하거
""")

f.write("""집가고싶다""")   # 뒤에다가 붙임
f.close()


