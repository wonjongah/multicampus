import shutil

shutil.copy("live.txt", "live2.txt")