price = input('가격을 입력하세요 : ')
num = input('수량을 입력하세요 : ')
sum = int(price) * int(num)
print('총액은', sum, '원입니다.')