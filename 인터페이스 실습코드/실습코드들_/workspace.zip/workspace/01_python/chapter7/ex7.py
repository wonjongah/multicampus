def kim():
    temp = "원과장의 함수"
    print(temp)


kim()
print(temp)