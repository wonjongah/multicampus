price = 1000


def sale():
    global price
    price = 500


sale()
print(price)