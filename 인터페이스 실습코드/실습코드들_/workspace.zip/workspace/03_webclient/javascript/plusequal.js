// 문자열에 어펜드하는 방법

var order = "";
order += "date : 2020-08-03";
order += "\n";
order += "item : notebook";
order += "\n";
order += "price : 134";

console.log(order);