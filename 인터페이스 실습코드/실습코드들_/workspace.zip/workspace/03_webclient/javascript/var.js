var a = 12;
var b = "korea";
var c
console.log("a = " + a);
console.log("b = " + b);
console.log("c = ", c);
console.log("d = ", d);

// ctrl + slash 주석처리

