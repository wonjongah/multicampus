var human = {
    name: "김상형",
    age: 29
}

var name = 'age';
// 객체 리터럴

console.log("name = " + human["name"]);
console.log("age = " + human["age"]);
console.log("age를 가진 name 변수 = " + human[name]);