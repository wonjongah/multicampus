const MILE = 1.609;
var marathon = 42.195;
console.log("마라톤 코스의 길이는 " + (marathon / MILE) + "마일이다.");

// 상수 키워드 const를 쓴 변수의 값을 변경하려면 오류