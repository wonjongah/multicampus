var a = 3;

if(a == 3){
    console.log("a는 3입니다");
}
else{
    console.log("a는 3이 아닙니다")
}