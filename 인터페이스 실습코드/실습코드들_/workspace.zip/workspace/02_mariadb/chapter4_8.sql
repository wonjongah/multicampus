USE sqldb;

UPDATE buytbl2 SET price = price * 1.5;