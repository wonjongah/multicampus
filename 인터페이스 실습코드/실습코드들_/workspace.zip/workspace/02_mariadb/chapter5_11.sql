USE sqldb;

SELECT * INTO OUTFILE 'C:/temp/userTBL.txt' FROM userTBL;