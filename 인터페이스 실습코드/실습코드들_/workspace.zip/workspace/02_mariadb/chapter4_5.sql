USE sqldb;

INSERT INTO testtbl3 VALUES
(NULL, '종아', 25),
(NULL, '경식', 27),
(NULL, '초엽', 22);